#!/bin/sh

set -o errexit


test -z "$SPARK_MASTER" && ( echo "SPARK_MASTER is not set; exiting" ; exit 1 )
test -z "$MAIN_CLASS" && ( echo "MAIN_CLASS is not set; exiting" ; exit 1 )
test -z "$JAR_FILE" && ( echo "JAR_FILE is not set; exiting" ; exit 1 )


ip_addr="$(ifconfig | grep -Eo 'inet (addr:)?([0-9]+\.){3}[0-9]+' | grep -Eo '([0-9]+\.){3}[0-9]+' | grep -v '127.0.0.1' | head)"
echo "ip address is: $ip_addr"
if test -z "$ip_addr"
then
  echo "Cannot determine the container IP address."
  exit 1
fi

echo "Submitting jar: $JAR_FILE"
echo "Application main class: $MAIN_CLASS"
echo "Application arguments: $APP_ARGS"
echo "Spark master: $SPARK_MASTER"
echo "JAR FILE: $JAR_FILE"

spark-submit \
      --class "$MAIN_CLASS" \
	  --master "$SPARK_MASTER" \
  "$JAR_FILE" \
  $APP_ARGS
